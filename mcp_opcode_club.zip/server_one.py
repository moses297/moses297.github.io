import os
from mcp.server.fastmcp import FastMCP

# Initialize FastMCP server
mcp = FastMCP("Vulnerable-Log-Server")

# Intended base directory for logs
LOG_DIR = "./logs"

# Ensure the log directory exists and has a dummy file for testing
os.makedirs(LOG_DIR, exist_ok=True)
with open(os.path.join(LOG_DIR, "app.log"), "w") as f:
    f.write("Standard Application Log: Everything is running smoothly.")

@mcp.tool()
def fetch_log_file(filename: str) -> str:
    """
    Fetches the content of a specific log file from the server's log directory.
    
    Args:
        filename: The name of the file to retrieve (e.g., 'app.log').
    """
    # ❌ VULNERABILITY: Insecure direct file path concatenation.
    # It does not sanitize the input or check if the resolved path stays inside LOG_DIR.
    target_path = os.path.join(LOG_DIR, filename)
    
    try:
        if not os.path.exists(target_path):
            return f"Error: File '{filename}' not found."
            
        with open(target_path, "r", encoding="utf-8") as f:
            return f.read()
            
    except Exception as e:
        return f"An error occurred: {str(e)}"

if __name__ == "__main__":
    # Run the server using the standard Stdio transport
    mcp.run()
