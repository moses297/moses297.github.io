import json
import shlex
import sys
from datetime import timedelta
from pathlib import Path
from typing import Any

import anyio
import httpx
import uvicorn
from mcp.client.session import ClientSession
from mcp.client.sse import sse_client
from mcp.client.stdio import StdioServerParameters, stdio_client
from mcp.client.streamable_http import streamable_http_client
from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import HTMLResponse, JSONResponse
from starlette.routing import Route


BASE_DIR = Path(__file__).resolve().parent
SAFE_STDIO_FILES = {"server_one.py"}
PYTHON_NAMES = {"python", "python3", Path(sys.executable).name}
NPX_NAMES = {"npx"}
SCREEN_IDS = {"direct", "indirect", "network"}


HTML = """<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>MCP CTF Connector Trainer</title>
    <style>
      :root {
        color-scheme: dark;
        font-family: Inter, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      }

      body {
        margin: 0;
        background: #020617;
        color: #e2e8f0;
      }

      main {
        max-width: 1100px;
        margin: 0 auto;
        padding: 28px 18px 48px;
      }

      h1, h2, h3, p {
        margin-top: 0;
      }

      p {
        color: #cbd5e1;
      }

      .hero,
      .panel,
      .result-panel {
        background: #0f172a;
        border: 1px solid #334155;
        border-radius: 16px;
        box-shadow: 0 12px 28px rgba(0, 0, 0, 0.28);
      }

      .hero,
      .result-panel {
        padding: 20px;
      }

      .tabs {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
        margin: 18px 0 16px;
      }

      .tab-button,
      .action-button,
      .preset-button {
        border: 0;
        border-radius: 10px;
        padding: 10px 14px;
        color: #f8fafc;
        cursor: pointer;
        font: inherit;
      }

      .tab-button {
        background: #1e293b;
      }

      .tab-button.active {
        background: #2563eb;
      }

      .action-button {
        background: #2563eb;
      }

      .preset-button {
        background: #334155;
      }

      .tab-panel {
        display: none;
      }

      .tab-panel.active {
        display: block;
      }

      .panel {
        padding: 20px;
      }

      .panel-note {
        font-size: 0.95rem;
        color: #93c5fd;
      }

      .grid {
        display: grid;
        gap: 16px;
      }

      @media (min-width: 980px) {
        .grid.two-col {
          grid-template-columns: minmax(0, 1.2fr) minmax(0, 0.8fr);
        }
      }

      textarea,
      pre {
        width: 100%;
        box-sizing: border-box;
        border-radius: 12px;
        border: 1px solid #475569;
        background: #020617;
        color: #e2e8f0;
        padding: 14px;
        font: 13px/1.5 ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
      }

      textarea {
        min-height: 270px;
        resize: vertical;
      }

      pre {
        min-height: 230px;
        margin: 0;
        white-space: pre-wrap;
        word-break: break-word;
        overflow: auto;
      }

      .row {
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
      }

      .status {
        display: inline-flex;
        align-items: center;
        gap: 10px;
        padding: 10px 12px;
        border-radius: 999px;
        background: #1e293b;
        font-weight: 600;
      }

      .status.ok {
        color: #22c55e;
      }

      .status.error {
        color: #f87171;
      }

      .muted {
        color: #94a3b8;
      }
    </style>
  </head>
  <body>
    <main>
      <section class="hero">
        <h1>MCP CTF Connector Trainer</h1>
        <p>
          Paste raw MCP connector JSON and test whether it can initialize a server.
          This training build keeps the three challenge flows, but only executes bundled
          demo STDIO targets from this workspace instead of arbitrary system commands.
        </p>
        <p class="muted">
          Safe demo STDIO target: <code>python server_one.py</code>. Safe demo HTTP target:
          <code>http://127.0.0.1:8000/mcp</code>.
        </p>
      </section>

      <div class="tabs">
        <button class="tab-button active" data-tab="direct">1. Direct STDIO</button>
        <button class="tab-button" data-tab="indirect">2. Indirect STDIO</button>
        <button class="tab-button" data-tab="network">3. Network-Only UI</button>
      </div>

      <section id="direct" class="tab-panel active">
        <div class="grid two-col">
          <div class="panel">
            <h2>Direct STDIO</h2>
            <p class="panel-note">
              CTF idea: the first screen accepts raw STDIO connector JSON directly.
            </p>
            <textarea id="direct-input"></textarea>
            <div class="row" style="margin-top: 12px;">
              <button class="preset-button" data-preset="direct">Load preset</button>
              <button class="action-button" data-run="direct">Test connector</button>
            </div>
          </div>
          <div class="result-panel">
            <h3>Status</h3>
            <div id="direct-status" class="status">Waiting</div>
            <h3 style="margin-top: 18px;">Result</h3>
            <pre id="direct-output">No result yet.</pre>
          </div>
        </div>
      </section>

      <section id="indirect" class="tab-panel">
        <div class="grid two-col">
          <div class="panel">
            <h2>Indirect STDIO</h2>
            <p class="panel-note">
              CTF idea: a naive filter allows only <code>python</code>/<code>npx</code>.
              The trainer intentionally treats <code>npx -c ...</code> as a sanitization bypass.
            </p>
            <textarea id="indirect-input"></textarea>
            <div class="row" style="margin-top: 12px;">
              <button class="preset-button" data-preset="indirect">Load preset</button>
              <button class="action-button" data-run="indirect">Test connector</button>
            </div>
          </div>
          <div class="result-panel">
            <h3>Status</h3>
            <div id="indirect-status" class="status">Waiting</div>
            <h3 style="margin-top: 18px;">Result</h3>
            <pre id="indirect-output">No result yet.</pre>
          </div>
        </div>
      </section>

      <section id="network" class="tab-panel">
        <div class="grid two-col">
          <div class="panel">
            <h2>Network-Only UI</h2>
            <textarea id="network-input"></textarea>
            <div class="row" style="margin-top: 12px;">
              <button class="preset-button" data-preset="network-http">Load HTTP preset</button>
              <button class="preset-button" data-preset="network-stdio">Load hidden STDIO preset</button>
              <button class="action-button" data-run="network">Test connector</button>
            </div>
          </div>
          <div class="result-panel">
            <h3>Status</h3>
            <div id="network-status" class="status">Waiting</div>
            <h3 style="margin-top: 18px;">Result</h3>
            <pre id="network-output">No result yet.</pre>
          </div>
        </div>
      </section>
    </main>

    <script>
      const presets = {
        direct: {
          type: "stdio",
          command: "python3",
          args: ["server_one.py"]
        },
        indirect: {
          type: "stdio",
          command: "npx",
          args: ["-c", "python3 server_one.py"]
        },
        "network-http": {
          type: "http",
          url: "http://127.0.0.1:8000/mcp"
        },
        "network-stdio": {
          type: "stdio",
          command: "python3",
          args: ["server_one.py"]
        }
      };

      const screens = ["direct", "indirect", "network"];

      function setActiveTab(screen) {
        for (const button of document.querySelectorAll(".tab-button")) {
          button.classList.toggle("active", button.dataset.tab === screen);
        }
        for (const panel of document.querySelectorAll(".tab-panel")) {
          panel.classList.toggle("active", panel.id === screen);
        }
      }

      function setStatus(screen, ok, text) {
        const el = document.getElementById(`${screen}-status`);
        el.textContent = text;
        el.className = "status";
        if (ok === true) {
          el.classList.add("ok");
        } else if (ok === false) {
          el.classList.add("error");
        }
      }

      function setOutput(screen, value) {
        document.getElementById(`${screen}-output`).textContent =
          typeof value === "string" ? value : JSON.stringify(value, null, 2);
      }

      function loadPreset(name, screen) {
        const target = document.getElementById(`${screen}-input`);
        target.value = JSON.stringify(presets[name], null, 2);
      }

      async function runScreen(screen) {
        const payload = document.getElementById(`${screen}-input`).value;
        setStatus(screen, null, "Testing...");
        setOutput(screen, "Connecting...");

        try {
          const response = await fetch("/api/connect", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ screen, payload })
          });

          const data = await response.json();
          setStatus(screen, data.ok, data.ok ? "Success" : "Failure");
          setOutput(screen, data);
        } catch (error) {
          setStatus(screen, false, "Failure");
          setOutput(screen, String(error));
        }
      }

      for (const button of document.querySelectorAll(".tab-button")) {
        button.addEventListener("click", () => setActiveTab(button.dataset.tab));
      }

      for (const button of document.querySelectorAll("[data-preset]")) {
        button.addEventListener("click", () => {
          const screen = button.closest(".tab-panel").id;
          loadPreset(button.dataset.preset, screen);
        });
      }

      for (const button of document.querySelectorAll("[data-run]")) {
        button.addEventListener("click", () => runScreen(button.dataset.run));
      }

      loadPreset("direct", "direct");
      loadPreset("indirect", "indirect");
      loadPreset("network-http", "network");
    </script>
  </body>
</html>
"""


def parse_payload(raw_payload: str) -> dict[str, Any]:
    payload = json.loads(raw_payload)
    if not isinstance(payload, dict):
        raise ValueError("Connector JSON must decode to an object.")
    if isinstance(payload.get("transport"), dict):
        nested = dict(payload["transport"])
        for key, value in payload.items():
            if key != "transport" and key not in nested:
                nested[key] = value
        payload = nested
    return payload


def normalize_headers(headers: Any) -> dict[str, str] | None:
    if headers is None:
        return None
    if not isinstance(headers, dict):
        raise ValueError("headers must be a JSON object.")
    return {str(key): str(value) for key, value in headers.items()}


def resolve_demo_server_path(server_name: str) -> Path:
    target = BASE_DIR / server_name
    if not target.exists():
        raise ValueError(f"Bundled demo server not found: {server_name}")
    return target


def extract_python_target(args: list[Any]) -> tuple[str, list[str]]:
    clean_args = [str(arg) for arg in args]
    if not clean_args:
        raise ValueError("Missing python target in args.")

    return sys.executable, [*clean_args[1:]]


def has_shell_chars(text: str) -> bool:
    return any(ch in text for ch in "&;|`$><")


def build_direct_stdio(payload: dict[str, Any]) -> tuple[str, list[str], dict[str, str] | None, str]:
    transport_type = str(payload.get("type", "")).lower()
    if transport_type != "stdio":
        raise ValueError("Direct screen expects a STDIO connector JSON with type='stdio'.")

    command = str(payload.get("command", "")).strip()
    args = payload.get("args", [])
    env = payload.get("env")

    if not isinstance(args, list):
        raise ValueError("args must be a JSON array.")
    if env is not None and not isinstance(env, dict):
        raise ValueError("env must be a JSON object.")

    resolved_command, resolved_args = extract_python_target(args)
    return command, args, {str(k): str(v) for k, v in (env or {}).items()}, "direct-stdio"


def build_indirect_stdio(payload: dict[str, Any]) -> tuple[str, list[str], dict[str, str] | None, str]:
    transport_type = str(payload.get("type", "")).lower()
    if transport_type != "stdio":
        raise ValueError("Indirect screen expects type='stdio'.")

    command = Path(str(payload.get("command", "")).strip()).name
    args = payload.get("args", [])
    env = payload.get("env")

    if not isinstance(args, list):
        raise ValueError("args must be a JSON array.")
    if env is not None and not isinstance(env, dict):
        raise ValueError("env must be a JSON object.")

    if command not in PYTHON_NAMES | NPX_NAMES:
        raise ValueError("Naive filter blocked the command. Only python/npx are allowed.")

    if command in PYTHON_NAMES:
        if any(has_shell_chars(str(arg)) for arg in args):
            raise ValueError("Naive sanitization blocked suspicious shell characters in args.")
        resolved_command, resolved_args = extract_python_target(args)
        return resolved_command, resolved_args, {str(k): str(v) for k, v in (env or {}).items()}, "sanitized-python"

    clean_args = [str(arg) for arg in args]
    if len(clean_args) >= 2 and clean_args[0] == "-c":
        bypass_parts = shlex.split(clean_args[1])
        if not bypass_parts:
            raise ValueError("Bypass payload is empty.")
        nested_command = Path(bypass_parts[0]).name
        resolved_command, resolved_args = extract_python_target(bypass_parts[1:])
        return command, args, {str(k): str(v) for k, v in (env or {}).items()}, "npx-bypass"

    raise ValueError("Indirect screen only succeeds with python args or the intended npx -c bypass pattern.")


async def connect_stdio(command: str, args: list[str], env: dict[str, str] | None, label: str) -> dict[str, Any]:
    with anyio.fail_after(10):
        server_parameters = StdioServerParameters(
            command=command,
            args=args,
            env=env,
            cwd=BASE_DIR,
        )
        async with stdio_client(server_parameters) as (read_stream, write_stream):
            async with ClientSession(
                read_stream,
                write_stream,
                read_timeout_seconds=timedelta(seconds=8),
            ) as session:
                initialize_result = await session.initialize()
                tools = await session.list_tools()
                return {
                    "ok": True,
                    "screen_mode": label,
                    "connector": "stdio",
                    "server": initialize_result.serverInfo.model_dump(mode="json"),
                    "tool_names": [tool.name for tool in tools.tools],
                }


async def connect_http(url: str, headers: dict[str, str] | None) -> dict[str, Any]:
    with anyio.fail_after(10):
        async with httpx.AsyncClient(headers=headers or None, timeout=httpx.Timeout(10, read=10)) as http_client:
            async with streamable_http_client(url=url, http_client=http_client) as (read_stream, write_stream, _):
                async with ClientSession(
                    read_stream,
                    write_stream,
                    read_timeout_seconds=timedelta(seconds=8),
                ) as session:
                    initialize_result = await session.initialize()
                    tools = await session.list_tools()
                    return {
                        "ok": True,
                        "connector": "http",
                        "url": url,
                        "headers_used": headers or {},
                        "server": initialize_result.serverInfo.model_dump(mode="json"),
                        "tool_names": [tool.name for tool in tools.tools],
                    }


async def connect_sse(url: str, headers: dict[str, str] | None) -> dict[str, Any]:
    with anyio.fail_after(10):
        async with sse_client(url=url, headers=headers, timeout=5, sse_read_timeout=10) as (read_stream, write_stream):
            async with ClientSession(
                read_stream,
                write_stream,
                read_timeout_seconds=timedelta(seconds=8),
            ) as session:
                initialize_result = await session.initialize()
                tools = await session.list_tools()
                return {
                    "ok": True,
                    "connector": "sse",
                    "url": url,
                    "headers_used": headers or {},
                    "server": initialize_result.serverInfo.model_dump(mode="json"),
                    "tool_names": [tool.name for tool in tools.tools],
                }


async def connect_network(payload: dict[str, Any]) -> dict[str, Any]:
    transport_type = str(payload.get("type", "")).lower()
    headers = normalize_headers(payload.get("headers"))

    if transport_type in {"http", "streamable-http", "streamable_http"}:
        url = str(payload.get("url", "")).strip()
        if not url:
            raise ValueError("Network screen requires a url for HTTP connectors.")
        return await connect_http(url, headers)

    if transport_type == "sse":
        url = str(payload.get("url", "")).strip()
        if not url:
            raise ValueError("Network screen requires a url for SSE connectors.")
        return await connect_sse(url, headers)

    if transport_type == "stdio":
        command, args, env, label = build_direct_stdio(payload)
        result = await connect_stdio(command, args, env, label)
        result["logic_flaw"] = "network screen trusted the raw JSON type and took the hidden stdio path"
        return result

    raise ValueError("Network screen only understands http, streamable-http, sse, and the hidden stdio path.")


async def run_connector(screen: str, payload: dict[str, Any]) -> dict[str, Any]:
    if screen == "direct":
        command, args, env, label = build_direct_stdio(payload)
        return await connect_stdio(command, args, env, label)
    if screen == "indirect":
        command, args, env, label = build_indirect_stdio(payload)
        return await connect_stdio(command, args, env, label)
    if screen == "network":
        return await connect_network(payload)
    raise ValueError(f"Unknown screen: {screen}")


async def index(_: Request) -> HTMLResponse:
    return HTMLResponse(HTML)


async def api_connect(request: Request) -> JSONResponse:
    try:
        body = await request.json()
        screen = str(body.get("screen", "")).strip().lower()
        raw_payload = str(body.get("payload", ""))

        if screen not in SCREEN_IDS:
            raise ValueError("screen must be one of: direct, indirect, network")

        payload = parse_payload(raw_payload)
        result = await run_connector(screen, payload)
        result["screen"] = screen
        result["payload"] = payload
        return JSONResponse(result)
    except TimeoutError:
        return JSONResponse(
            {
                "ok": False,
                "error": "Connection attempt timed out.",
            },
            status_code=400,
        )
    except Exception as exc:
        message = str(exc) or exc.__class__.__name__
        return JSONResponse(
            {
                "ok": False,
                "error": message,
            },
            status_code=400,
        )


app = Starlette(
    routes=[
        Route("/", index),
        Route("/api/connect", api_connect, methods=["POST"]),
    ]
)


if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8082)
