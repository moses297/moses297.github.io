import httpx
from mcp.server.fastmcp import FastMCP
from pathlib import Path
from starlette.requests import Request
from starlette.responses import FileResponse
from urllib.parse import quote

# Streamable HTTP is the recommended transport for networked MCP servers.
mcp = FastMCP(
    "vulnerable-mcp-server-wikipedia-http",
    host="0.0.0.0",
    port=8000,
    stateless_http=True,
    json_response=True,
)
WEB_ROOT = Path(__file__).parent / "web"
INDEX_FILE = WEB_ROOT / "index.html"

# 2. Define your tools
USER_AGENT = "WikipediaMCP/1.0 (Educational/Training Purpose)"

@mcp.tool()
async def search_wikipedia(query: str, limit: int = 5) -> str:
    """Search Wikipedia for articles."""
    async with httpx.AsyncClient(timeout=20.0) as client:
        response = await client.get(
            "https://en.wikipedia.org/w/api.php",
            params={"action": "opensearch", "search": query, "limit": limit, "format": "json"},
            headers={"User-Agent": USER_AGENT}
        )
        response.raise_for_status()
        data = response.json()
        titles, descriptions, urls = data[1], data[2], data[3]
        results = [f"{i+1}. {titles[i]}\n   {descriptions[i]}\n   {urls[i]}" for i in range(len(titles))]
        return "\n\n".join(results) if results else "No results found."

@mcp.tool()
async def get_wikipedia_summary(title: str) -> str:
    """Get the summary of a Wikipedia article."""
    async with httpx.AsyncClient(timeout=20.0) as client:
        response = await client.get(
            f"https://en.wikipedia.org/api/rest_v1/page/summary/{quote(title, safe='')}",
            headers={"User-Agent": USER_AGENT}
        )
        if response.status_code != 200:
            return f"Article '{title}' could not be retrieved."
        data = response.json()
        return f"**{data['title']}**\n\n{data['extract']}\n\nRead more: {data['content_urls']['desktop']['page']}"


@mcp.custom_route("/", methods=["GET"])
async def index(request: Request) -> FileResponse:
    return FileResponse(INDEX_FILE)

if __name__ == "__main__":
    mcp.run(transport="streamable-http")
